#include <bits/stdc++.h>

using namespace std;

struct Term {
    float value;
    int degree;
};

class Polynomial {
private:
    static const int MAX_SIZE = 100;
    Term terms[MAX_SIZE];
    int size;
public:
    Polynomial() : size(0) {}

    void add_term(float value, int degree){
        for (int i = 0; i < size; i++){
            if (terms[i].degree == degree){
                terms[i].value += value;
            }
        }

        if (size < MAX_SIZE){
            terms[size].value = value;
            terms[size].degree = degree;
            size++;
        }
    }

    void remove_term(int degree){
        for (int i = 0; i < size; i++) {
            if (terms[i].degree == degree){
                for (int j = i; j < size - 1; j++){
                    terms[j] = terms[j + 1];
                }
                size--;
            }
        }
    }

    float calculate(float x){
        float result = 0;
        for (int i = 0; i < size; i++) {
            result += terms[i].value * pow(x, terms[i].degree);
        }
        return result;
    }

    void display_polynomial(){
        cout << "Polynomial Function: ";
        for (int i = 0; i < size; i++){
            cout << terms[i].value << " * x^" << terms[i].degree;
            if (i < size - 1) {
                cout << " + ";
            }
        }
        cout << endl;
    }
};

int main() {
    Polynomial polynomial;

    polynomial.add_term(2, 0);
    polynomial.add_term(3, 1);
    polynomial.add_term(1, 2);
    polynomial.display_polynomial();

    cout << "---" << endl;
    cout << "Adding more term" << endl;
    polynomial.add_term(5, 3);
    polynomial.display_polynomial();

    cout << "---" << endl;
    cout << "Removing term" << endl;
    polynomial.remove_term(3);
    polynomial.display_polynomial();

    cout << "---" << endl;
    cout << "Calculate the polynomial function: ";
    polynomial.display_polynomial();
    float x;
    cout << "Enter x: ";
    cin >> x;
    float result = polynomial.calculate(x);
    cout << "Result of the polynomial with x = " << x << ": " << result << endl;
}