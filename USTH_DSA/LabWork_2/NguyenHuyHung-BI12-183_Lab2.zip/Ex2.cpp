#include <bits/stdc++.h>

using namespace std;

struct Train_Car{
    int passengers;
    char name;
    Train_Car* next;

    Train_Car(int passengers, char name) : passengers(passengers), name(name), next(nullptr) {}
};

class Train{
private:
    Train_Car* head;
    int length;
public:
    Train() : head(nullptr), length(0) {}

    ~Train(){
        Train_Car* current = head;
        while (current != nullptr) {
            Train_Car* next = current->next;
            delete current;
            current = next;
        }
    }

    void add_cars(int passengers, char name){
        Train_Car* new_car = new Train_Car(passengers, name);
        if (head == nullptr){
            head = new_car;
        } 
        else{
            Train_Car* current = head;
            while (current->next != nullptr) {
                current = current->next;
            }
            current->next = new_car;
        }
        length++;
    }

    void remove_cars(){
        Train_Car* current = head;
        Train_Car* previous = nullptr;

        while (current != nullptr) {
            if (current->passengers == 0){
                if (previous == nullptr){
                    head = current->next;
                } 
                else{
                    previous->next = current->next;
                }
                Train_Car* temp = current;
                current = current->next;
                delete temp;
                length--;
            } 
            else{
                previous = current;
                current = current->next;
            }
        }
    }

    void display_cars(){
        Train_Car* current = head;
        while (current != nullptr) {
            cout << "Car " << current->name << " - Passengers: " << current->passengers << endl;
            current = current->next;
        }
    }

    int length_train(){
        return length;
    }
};

int main(){
    Train train;

    train.add_cars(0, 'A');
    train.add_cars(15, 'B');
    train.add_cars(0, 'C');
    train.add_cars(8, 'D');

    cout << "Train length:" << train.length_train() << endl;
    train.display_cars();

    cout << "---" << endl;
    cout << "Removing empty cars" << endl;
    train.remove_cars();
    cout << "Train length: " << train.length_train() << endl;
    train.display_cars();

    cout << "---" << endl;
    cout << "Adding more car" << endl;
    train.add_cars(22, 'E');
    cout << "Train length: " << train.length_train() << endl;
    train.display_cars();
}